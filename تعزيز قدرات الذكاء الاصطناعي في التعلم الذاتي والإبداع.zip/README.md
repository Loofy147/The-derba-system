# TuberOrchestratorAI: نظام الدرنة المدبرة

نظام "الدرنة المدبرة" (TuberOrchestratorAI) هو مشروع رائد يهدف إلى بناء نظام معرفي ذكي، تكيفي، وذاتي التطور، مستوحى من الأنظمة البيولوجية المعقدة والعمليات المعرفية البشرية. يجمع هذا النظام بين مفاهيم متقدمة في الذكاء الاصطناعي، مثل نماذج اللغة الكبيرة (LLMs)، والتعلم المعزز، وإدارة المعرفة القائمة على الرسوم البيانية، والتحسين الذاتي.

## الرؤية الأساسية (الدرنة الجذرية)

"دردتنا مبنية على Umbrella Architecture كـ Collaborative Ecosystem، تعمل كـ Meta-System ينسج Social Fabric مرنًا بين المشاركين؛ كل ذلك موجهًا من خلال Holistic Framework ومنسقًا عبر Holarchy of Communities of Practice، مما يعزز Collective Intelligence و Peer-to-Peer collaboration."

هذه الرؤية هي فلسفة التصميم التي توجه كل قرار وسلوك للنظام.

## الميزات الرئيسية

*   **شبكة الدرنات الديناميكية:** تمثيل المعرفة كشبكة متفرعة من "الدرنات" (TuberNodes) المترابطة دلاليًا.
*   **المثلث المعرفي النشط (AKT):** آلية تركيز ديناميكية تسمح للنظام بالتركيز على ثلاث درنات مترابطة في أي وقت.
*   **نظام المكافأة والتنبؤ:** يتنبأ بالمكافآت المستقبلية، ويحسب الندم المتوقع، ويتعلم من الأخطاء ليوجه قراراته.
*   **طريق التحدي (Path of Challenge):** وكيل استكشاف مخصص يبحث عن مسارات غير تقليدية ومفاهيم مبتكرة.
*   **الوعي الذاتي والميتا-معرفي:** النظام قادر على فهم بنيته الخاصة، وتحليل دوافعه، واقتراح تحسينات استراتيجية.
*   **واجهة المطور الذكية:** تسمح للمطور بالتفاعل مع النظام بلغة طبيعية، وطلب اقتراحات كود، وتصميم وتشغيل تجارب آلية.
*   **آلية توليد الأسئلة:** يمتلك النظام فضولًا اصطناعيًا، حيث يكتشف الفجوات المعرفية ويولد أسئلة استقصائية لملء هذه الفجوات وتحسين فهمه.
*   **تحسين التكلفة والأداء:** يطبق استراتيجيات متقدمة لتقليل تكاليف استدعاءات LLM وتحسين سرعة الاستجابة.
*   **التحسين الذاتي:** يتعلم النظام باستمرار من تفاعلاته وبيئته، ويقترح تحسينات على كوده وهيكله، ويختبرها بشكل آلي.

## هيكل المشروع

```
tuber_orchestrator_ai/
├── __init__.py
├── main.py                 # نقطة الدخول الرئيسية للتفاعل مع النظام
├── tuber_core.py           # تعريف TuberNode, MetaphoricalTuberingModel (شبكة الدرنات)
├── tuber_orchestrator.py   # الفئة الرئيسية TuberOrchestratorAI (المنطق العام، المكافآت، التجارب)
├── challenge_agent.py      # EnhancedChallengeAgent (وكيل طريق التحدي)
├── llm_interface.py        # واجهة موحدة للتعامل مع نماذج اللغة الكبيرة (LLMs)
├── meta_cognitive.py       # وحدة الوعي الميتا-معرفي
├── question_generator.py   # محرك توليد الأسئلة
├── question_classifier.py  # مصنف جودة الأسئلة
├── question_memory.py      # ذاكرة الأسئلة الفاشلة
└── config.py               # إعدادات النظام والثوابت
```

## الإعداد والتشغيل

للبدء في تشغيل واستكشاف نظام TuberOrchestratorAI على جهازك، اتبع الخطوات التالية:

### 1. المتطلبات الأساسية

تأكد من تثبيت Python 3.9 أو أحدث على نظامك.

### 2. إعداد المشروع

أ. **إنشاء مجلد المشروع:**
   أنشئ مجلدًا جديدًا لمشروعك، على سبيل المثال `my_tuber_project`.

ب. **حفظ الملفات:**
   داخل مجلد `my_tuber_project`، أنشئ مجلدًا فرعيًا باسم `tuber_orchestrator_ai`. ثم قم بحفظ جميع ملفات الكود التي تم توفيرها لك (`config.py`, `llm_interface.py`, `tuber_core.py`, `challenge_agent.py`, `tuber_orchestrator.py`, `main.py`, `meta_cognitive.py`, `question_generator.py`, `question_classifier.py`, `question_memory.py`) داخل مجلد `tuber_orchestrator_ai`.

   يجب أن يبدو هيكل ملفاتك كالتالي:
   ```
   my_tuber_project/
   ├── tuber_orchestrator_ai/
   │   ├── __init__.py
   │   ├── main.py
   │   ├── tuber_core.py
   │   ├── tuber_orchestrator.py
   │   ├── challenge_agent.py
   │   ├── llm_interface.py
   │   ├── meta_cognitive.py
   │   ├── question_generator.py
   │   ├── question_classifier.py
   │   ├── question_memory.py
   │   └── config.py
   └── .env  (سيتم إنشاؤه في الخطوة التالية)
   ```

ج. **إنشاء بيئة افتراضية (موصى به بشدة):**
   افتح الطرفية (Terminal) أو موجه الأوامر (Command Prompt)، وانتقل إلى مجلد `my_tuber_project`:
   ```bash
   cd path/to/my_tuber_project
   ```
   ثم قم بإنشاء وتفعيل البيئة الافتراضية:
   ```bash
   python3 -m venv tuber_env
   # لتفعيل البيئة الافتراضية:
   # على Windows:
   # .\tuber_env\Scripts\activate
   # على macOS/Linux:
   # source tuber_env/bin/activate
   ```

د. **تثبيت المكتبات المطلوبة:**
   بعد تفعيل البيئة الافتراضية، قم بتثبيت جميع المكتبات اللازمة:
   ```bash
   pip install networkx sentence-transformers scikit-learn numpy openai anthropic python-dotenv
   ```

هـ. **إعداد مفاتيح API وملف `.env`:**
   ستحتاج إلى مفتاح API من مزود نموذج اللغة الكبير (LLM) الذي تختاره (مثل OpenAI أو Anthropic). بالإضافة إلى إعدادات النماذج المحلية إذا كنت تخطط لاستخدامها.
   في مجلد `my_tuber_project` (نفس مستوى مجلد `tuber_orchestrator_ai`)، قم بإنشاء ملف جديد باسم `.env` (تأكد من وجود النقطة في البداية). وضع فيه مفتاح API الخاص بك ونوع مزود LLM الذي ستستخدمه. مثال:

   **إذا كنت تستخدم OpenAI:**
   ```
   LLM_PROVIDER="openai"
   OPENAI_API_KEY="sk-YOUR_OPENAI_API_KEY_HERE"
   OPENAI_MODEL="gpt-4o" # أو أي نموذج آخر مثل gpt-3.5-turbo
   ```

   **إذا كنت تستخدم Anthropic:**
   ```
   LLM_PROVIDER="anthropic"
   ANTHROPIC_API_KEY="sk-YOUR_ANTHROPIC_API_KEY_HERE"
   ANTHROPIC_MODEL="claude-3-opus-20240229" # أو أي نموذج آخر
   ```

   **إذا كنت تستخدم نموذجًا محليًا (موصى به لتقليل التكاليف):**
   تأكد من تثبيت وتشغيل Ollama أو أي خادم LLM محلي آخر على جهازك. ثم قم بتنزيل النموذج الذي تريده (مثلاً `ollama run llama3`).
   ```
   LLM_PROVIDER="local"
   LOCAL_MODEL="llama3" # اسم النموذج الذي قمت بتنزيله في Ollama
   OLLAMA_HOST="http://localhost:11434" # العنوان الافتراضي لـ Ollama
   ```

   **إعدادات إضافية (اختياري):**
   يمكنك أيضًا تعديل الإعدادات الافتراضية للنظام عن طريق إضافتها إلى ملف `.env`. على سبيل المثال:
   ```
   LLM_TEMPERATURE=0.3
   LLM_MAX_TOKENS=500
   LLM_TOP_P=0.9
   MAX_TUBERS=500
   PRUNING_THRESHOLD=0.15
   EXPLORATION_BUDGET=0.1
   LOG_LEVEL=DEBUG # لتفاصيل أكثر في السجلات
   CURIOSITY_THRESHOLD=0.8 # عتبة الفضول لتوليد الأسئلة
   MAX_QUESTIONS_PER_SESSION=5 # الحد الأقصى للأسئلة في الدورة الواحدة
   LOCAL_LLM_COMPLEXITY_THRESHOLD=0.4 # عتبة تعقيد المهمة لاستخدام LLM المحلي (0.0 - 1.0)
   ```
   **ملاحظة هامة:** لا تشارك ملف `.env` الخاص بك مع أي شخص، فهو يحتوي على معلومات حساسة.

### 3. تشغيل النظام

بعد إكمال جميع خطوات الإعداد أعلاه، تأكد أنك لا تزال في مجلد `my_tuber_project` وأن البيئة الافتراضية مفعلة. ثم قم بتشغيل الملف الرئيسي:

```bash
python3 tuber_orchestrator_ai/main.py
```

### 4. التفاعل مع النظام

بمجرد تشغيل `main.py`، سترى رسالة ترحيب وموجه `Developer>`. يمكنك الآن التفاعل مع "الدرنة المدبرة" باستخدام الأوامر التالية:

*   `help`: لعرض قائمة الأوامر المتاحة. (موصى به للبدء)
*   `exit`: للخروج من التطبيق.
*   `status`: لعرض حالة النظام الحالية (عدد الدرنات، تكلفة LLM، إلخ).
*   `health`: للحصول على تقرير صحة النظام.
*   `list_experiments`: لعرض جميع التجارب المقترحة والمكتملة.
*   `chat <رسالتك>`: لإرسال رسالة عامة إلى الذكاء الاصطناعي (سيستخدم LLM للرد).
    *   مثال: `chat How can I improve tuber pruning efficiency?`
*   `suggest_code <وصف المشكلة>`: لطلب اقتراح كود لحل مشكلة معينة.
    *   مثال: `suggest_code Implement a new reward function that considers regret.`
*   `propose_experiment <الهدف>`: لطلب اقتراح تجربة آلية لتحسين جانب معين من النظام.
    *   مثال: `propose_experiment optimize LLM temperature for creative expansion`
*   `run_experiment <معرف_التجربة>`: لتشغيل تجربة مقترحة. ستحصل على المعرف بعد `propose_experiment`.
    *   مثال: `run_experiment exp_0`
*   `validate_code <معرف_الاقتراح>`: للتحقق من صحة اقتراح كود تم إنشاؤه مسبقًا. ستحصل على المعرف بعد `suggest_code`.
    *   مثال: `validate_code suggestion_0`
*   `run_automated_cycle <بيانات_المدخلات_JSON>`: لتشغيل دورة تلقائية كاملة للنظام، بما في ذلك آلية توليد الأسئلة.
    *   مثال: `run_automated_cycle {"context": "initial system startup", "focus": "knowledge gaps"}`

## نصائح وملاحظات هامة

*   **التكاليف:** استدعاءات LLM API تكلف مالًا. راقب استخدامك عن كثب، خاصة عند تشغيل التجارب أو عمليات التوسع المكثفة. يمكنك مراجعة `total_estimated_cost` عبر أمر `status`.
*   **الاستضافة المحلية:** استخدام LLM محليًا (مثل Ollama) سيقلل التكاليف بشكل كبير ويوفر تحكمًا أكبر في الخصوصية. تأكد من إعداده بشكل صحيح قبل اختيار `LLM_PROVIDER="local"`.
*   **الأداء:** قد تكون بعض العمليات (خاصة تلك التي تتضمن استدعاءات LLM متكررة) بطيئة. هذا طبيعي ويعتمد على سرعة استجابة LLM وقوة جهازك.
*   **التكرار:** هذا المشروع هو عملية تكرارية. ستقوم بتشغيل النظام، ومراقبة سلوكه، وتعديل الكود، ثم تكرار العملية. لا تتوقع الكمال من أول تشغيل.
*   **الاستكشاف:** جرب الأوامر المختلفة، خاصة `propose_experiment` و `suggest_code`، و `run_automated_cycle` لترى كيف يبدأ النظام في التفكير والتطوير الذاتي.
*   **التخصيص:** يمكنك تعديل الكود في أي من الملفات (خاصة `config.py` و `tuber_orchestrator.py`) لتجربة أفكارك الخاصة.
*   **الوعي الذاتي:** تذكر أن النظام يحاول فهم نفسه. يمكنك أن تطلب منه `chat` حول "لماذا اتخذ هذا القرار؟" أو "كيف يمكنني تحسين عملية التفكير لديك؟" (بشكل مجازي).

نتمنى لك تجربة ممتعة ومثمرة مع "الدرنة المدبرة"!



