import random
from typing import Dict, Any, List, Optional
import logging

from config import Config

logging.basicConfig(level=Config.LOG_LEVEL, format="%(asctime)s - %(levelname)s - %(message)s")

class MetaCognitiveModule:
    def __init__(self, llm_interface_instance):
        self.llm_interface = llm_interface_instance
        self.curiosity_level = 0.5 # Can be dynamically adjusted

    def detect_gaps(self, system_state: Dict[str, Any]) -> List[str]:
        """
        Monitors system state, LLM outputs, and internal predictions for knowledge gaps.
        This is a heuristic-based function that can be significantly improved.
        """
        gaps = []
        
        # Example: Low prediction confidence
        if system_state.get('avg_prediction_confidence', 1.0) < 0.6:
            gaps.append("Low overall prediction confidence in the system.")
        
        # Example: High prediction error
        if system_state.get('avg_prediction_error', 0.0) > 0.3:
            gaps.append("High discrepancy between predicted and actual rewards.")
            
        # Example: Stagnant exploration
        if system_state.get('stagnant_exploration_cycles', 0) > 3:
            gaps.append("Exploration has been stagnant or unsuccessful recently.")

        # Example: Unexplored but potentially important tubers
        if system_state.get('high_potential_unexplored_tubers', 0) > 0:
            gaps.append("There are tubers with high potential but low exploration.")

        # Example: Frequent use of a specific tuber without deep understanding
        if system_state.get('overused_tuber_id'):
            gaps.append(f"The tuber {system_state['overused_tuber_id']} is frequently used but may not be fully understood.")

        # Random curiosity trigger
        if not gaps and random.random() < 0.1:
            gaps.append("Random curiosity trigger: What if we question a core assumption?")
            
        return gaps

    def calculate_curiosity_score(self, gaps: List[str]) -> float:
        """
        Calculates a curiosity score based on the detected gaps.
        """
        # Simple heuristic: more gaps, more curiosity
        score = min(1.0, len(gaps) * 0.25 + self.curiosity_level * 0.1)
        return score

    async def generate_inner_dialogue(self, gaps: List[str], system_state: Dict[str, Any]) -> str:
        """
        Generates an 'inner dialogue' using an LLM to reflect on the system's state and gaps.
        This dialogue helps in formulating targeted questions.
        """
        if not self.llm_interface:
            return "LLM Interface not available for inner dialogue."

        prompt = f"""
        As a meta-cognitive module for an AI system, reflect on the following state and identified gaps.
        Your goal is to generate a brief internal monologue that synthesizes these issues and points towards a direction for inquiry.

        Current System State:
        {system_state}

        Identified Gaps:
        - {"\n- ".join(gaps)}

        Generate a concise inner dialogue (2-3 sentences) that captures the essence of the current challenge or uncertainty.
        Example: 'My predictions have been off lately, especially when dealing with novel concepts. It seems I'm overfitting to past successes. Perhaps I need to question my core reward function or explore more radically different ideas.'
        """
        
        dialogue, _ = await self.llm_interface.generate_text(prompt, max_tokens=150, temperature=0.7)
        logging.info(f"Generated Inner Dialogue: {dialogue}")
        return dialogue


