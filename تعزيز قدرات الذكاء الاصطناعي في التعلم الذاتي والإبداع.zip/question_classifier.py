from typing import Dict, Any, List

class QuestionQualityClassifier:
    def __init__(self):
        self.threshold = 0.7 # عتبة جودة السؤال

    def score(self, question: str) -> float:
        """
        يصنف وضوح ومناسبة الأسئلة قبل عرضها.
        هذه دالة وهمية تحتاج إلى منطق حقيقي (ربما باستخدام LLM).
        """
        # مثال بسيط: يعتمد على طول السؤال ووجود علامة استفهام
        clarity_score = 1.0 if question.endswith("?") and len(question) > 10 else 0.5
        relevance_score = 0.8 # يمكن أن يعتمد على مدى ارتباط السؤال بالسياق
        
        # يمكن استخدام LLM هنا لتقييم جودة السؤال
        # prompt = f"Evaluate the clarity and relevance of the following question: \"{question}\". Provide a score between 0 and 1 for each."
        # llm_response = LLMInterface.ask(prompt)
        
        return (clarity_score + relevance_score) / 2.0

    def is_useful(self, answer: str) -> bool:
        """
        يحدد ما إذا كانت الإجابة مفيدة أم لا.
        """
        # مثال بسيط: الإجابة مفيدة إذا لم تكن قصيرة جداً أو تحتوي على كلمات سلبية
        if not answer or len(answer.strip()) < 20 or "I don't know" in answer.lower() or "cannot answer" in answer.lower():
            return False
        return True

    def rephrase(self, question: str) -> str:
        """
        يعيد صياغة الأسئلة الضعيفة تلقائيًا.
        """
        # يمكن استخدام LLM هنا لإعادة الصياغة
        # prompt = f"Rephrase the following question to be clearer and more concise: \"{question}\"."
        # llm_response = LLMInterface.ask(prompt)
        return f"Can you clarify: {question}"


