from typing import List, Dict, Any
import time

class FailedQuestionMemory:
    def __init__(self):
        self.failed_questions: List[Dict[str, Any]] = []

    def store(self, question: str, context: Dict[str, Any] = None):
        """
        يخزن الأسئلة التي لم تحصل على إجابات مفيدة.
        """
        entry = {
            "question": question,
            "context": context if context else {},
            "timestamp": time.time()
        }
        self.failed_questions.append(entry)
        print(f"[FailedQuestionMemory] Stored failed question: \"{question[:50]}...\"")

    def retrieve_for_retraining(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        يسترجع الأسئلة الفاشلة لاستخدامها كنماذج سلبية لإعادة التدريب الداخلي.
        """
        # يمكن إضافة منطق أكثر تعقيدًا هنا (مثل استرجاع الأسئلة الأقدم، أو الأكثر تكرارًا)
        return self.failed_questions[-limit:]

    def clear_memory(self):
        """
        يمسح الذاكرة.
        """
        self.failed_questions = []
        print("[FailedQuestionMemory] Memory cleared.")

    def get_memory_size(self) -> int:
        return len(self.failed_questions)


